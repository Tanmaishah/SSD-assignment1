let sum=0
awk -F',' '{sum= sum + $4} END {print sum}' power_levels.txt


