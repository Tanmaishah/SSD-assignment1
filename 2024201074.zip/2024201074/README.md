Q1:
    I have used the -E command which lets us find statements which have both our required keywords(i.e here POST and 404.)
    
Q2:
    I have used the  awk command and accessed the 4th word of every line using $4 then i have added it to a variable which was initially zero.
